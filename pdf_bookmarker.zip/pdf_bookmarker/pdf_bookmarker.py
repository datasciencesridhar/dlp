# pip install flask
# pip install flask-wtf
import os
os.chdir('C:\\Users\\anves\\OneDrive\\Desktop\\pdf_bookmarker')# path of th flask application
from flask import Flask, render_template, url_for, flash, redirect
from forms import InputForm
from bookmarking_any_pdf import bookmarker
import pythoncom
app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
@app.route("/about")
def about():
    return render_template('about.html')

@app.route("/", methods=['GET', 'POST'])
def home():
    form = InputForm()
    if form.validate_on_submit():
        input_path= form.input_path.data +'\\'
        output_path = form.output_path.data +'\\'
        print('\n\n',output_path,'\n\n')
        result = bookmarker(input_path,output_path)
        os.chdir('C:\\Users\\anves\\OneDrive\\Desktop\\pdf_bookmarker')
        if result is True:
           flash("Al the files are bookmarked", 'success')
        else:
            flash(f"{result}    path not found...Please enter the path using '//' instead of'/'", 'danger')
        return redirect(url_for('about'))
    else:
       flash("Please enter the path using '//' instead of'/'", 'danger')
    return render_template('home.html', title='pdf bookmarker', form=form)


if __name__ == '__main__':
    app.run(debug=True)