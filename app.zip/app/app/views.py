from app import app
from flask import render_template
from flask import request, redirect, jsonify, make_response
from werkzeug.utils import secure_filename

import os


app.config["FILE_UPLOADS"] = "C:/Users/anves/OneDrive/Desktop/pdfs"
app.config["ALLOWED_IMAGE_EXTENSIONS"] = ["pdf", "PDF","docx"]

def allowed_file(filename):

    if not "." in filename:
        return False

    ext = filename.rsplit(".", 1)[1]

    if ext.upper() in app.config["ALLOWED_IMAGE_EXTENSIONS"]:
        return True
    else:
        return False

@app.route("/bookmark")
def about():
    return render_template("bookmark.html")

@app.route("/upload", methods=["GET", "POST"])
def upload_pdf():

    if request.method == "POST":

        file = request.files["file"]
        if file.filename == "":
            print("No filename")
            return redirect(request.url)
        
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config["FILE_UPLOADS"], filename))
        
        res = make_response(jsonify({"message": "File uploaded"}), 200)

        return res

    return render_template("upload.html")
