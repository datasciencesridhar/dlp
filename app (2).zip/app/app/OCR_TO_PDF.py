import os
import PyPDF2

def ocr_2_pdf(image_path,output_path,input_file,SCALE=1):
    os.chdir(image_path)
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    for pdf in x:
        scale = PyPDF2.PdfFileReader(pdf)
        page = scale.getPage(0)
        page.scaleBy(SCALE)
        writer = PyPDF2.PdfFileWriter()  # create a writer to save the updated results
        writer.addPage(page)
        with open(pdf , "wb+") as f:
            writer.write(f)
    
    y = [a for a in os.listdir() if a.endswith(".pdf")]
    merger = PyPDF2.PdfFileMerger()
    for pdf in y:
        merger.append(open(pdf, 'rb'))
    os.chdir(output_path)
    with open(input_file , "wb") as fout:
        merger.write(fout)
        merger.close()
    print('complete editable pdf is created')
    return True
