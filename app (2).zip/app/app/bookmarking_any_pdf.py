# create a input folder and place the input file 
# create a output folder
# create  a image folder  
# create a final folder
# install tessaract application from this url 
# ( https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-v5.0.0-alpha.20201127.exe )
# Then using pip install  open cv and install pytersseract
# pip install PyMuPDF
# pip install PyPDF2
# pip install pdfminer
import fitz
from win32com.client.dynamic import Dispatch
import pytesseract
import PyPDF2
import pythoncom
import os
import shutil
import time
from reportlab.pdfgen import canvas
from reportlab.lib import pdfencrypt

from .PDF_TO_IMAGE import pdf_pages_2_image
from .OCR import image_ocr
from .OCR_TO_PDF import ocr_2_pdf
from .PDF_TO_DOC import pdf_2_doc
from .DOC_TO_PDF_BOOKMARKER import doc_2_pdf_bookmarker
from .PDF_TO_PDF_BOOKMARKER import pdf_2_pdf_bookmarker
from .TOC import creating_table_of_contents
   
def get_pdf_searchable_pages(fname,input_folder,image_folder,output_folder,final_output_folder,toc_file):
    pythoncom.CoInitialize()
    from pdfminer.pdfpage import PDFPage
    searchable_pages = []
    non_searchable_pages = []
    paths=[]
    page_num = 0
    try:
        with open(fname, 'rb') as infile:
    
            for page in PDFPage.get_pages(infile):
                page_num += 1
                if 'Font' in page.resources.keys():
                    searchable_pages.append(page_num)
                else:
                    non_searchable_pages.append(page_num)
        if page_num > 0:
            if len(non_searchable_pages) == 0:
                print(f'{fname} is a text pdf.')
                pdf_name =fname
                pdf_file = os.path.abspath(pdf_name)
                temp_folder = os.path.join(toc_file, fname[0:-4]+"//")
                os.mkdir(temp_folder)
                print(temp_folder)
                paths.append(temp_folder)
                pdf_2_pdf_bookmarker(pdf_name,pdf_name,temp_folder)
                os.chdir(temp_folder)
                creating_table_of_contents(temp_folder,pdf_name)
                
                pdf_2_pdf_bookmarker(fname,fname,final_output_folder)
                os.chdir(input_folder)
                x = [a for a in os.listdir() if a.endswith(".pdf")]
                os.chdir(final_output_folder)
                for filename in os.listdir(final_output_folder):
                    if filename not in x:
                        src = final_output_folder + filename
                        dst = final_output_folder + pdf_name[0:-4]+'.pdf'
                        os.rename(src,dst)
                    else:
                        continue
    
            else:
                print(f"\n{fname} is a scanned pdf.")
                image_path = os.path.join(image_folder , fname[0:-4])
                os.mkdir(image_path)
                output_path = os.path.join(output_folder, fname[0:-4])
                os.mkdir(output_path)
                input_file =fname
                input_file = pdf_pages_2_image(input_folder,input_file,image_path)
                image_ocr(image_path)
                ocr_2_pdf(image_path, output_path,input_file,0.175)
                os.chdir(input_folder)
                paths.append(image_path)
                paths.append(output_path)
                x = [a for a in os.listdir() if a.endswith(".pdf")]
                os.chdir(output_path)
                y = [a for a in os.listdir() if a.endswith(".pdf")]
                for filename in y:
                        pdf_name =filename
                        pdf_file = os.path.abspath(pdf_name)
                        pdf_2_doc(pdf_file)
                z = [a for a in os.listdir() if a.endswith(".docx")]
                for filename in z:
                        doc_name =filename
                        doc_file = os.path.abspath(doc_name)
                        temp_folder = os.path.join(toc_file, fname[0:-4]+"//")
                        os.mkdir(temp_folder)
                        print(temp_folder)
                        doc_2_pdf_bookmarker(doc_file, doc_name,temp_folder)
                        os.chdir(temp_folder)
                        creating_table_of_contents(temp_folder,fname)
                        pdf_2_pdf_bookmarker(fname,fname,final_output_folder)
                        os.chdir(final_output_folder)
                        for filename in os.listdir(final_output_folder):
                            if filename not in x:
                                src = final_output_folder + filename
                                dst = final_output_folder + doc_name[0:-5]+'.pdf'
                                os.rename(src,dst)
                            else:
                                continue
    except:
        pass
    return paths  
                                  
def bookmarker(input_folder,output_folder,image_folder,final_output_folder,toc_file):
    pythoncom.CoInitialize()    
    os.chdir(input_folder)
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    dump = []
    Time = []
    for filename in x:
        start_time = time.time()
        paths = get_pdf_searchable_pages(filename,input_folder,image_folder,output_folder,final_output_folder,toc_file)
        dump.append(paths)
        os.chdir(input_folder)
        end_time = time.time()
        total = end_time-start_time
        Time.append(int(total))
    for i in dump:
        for j in i:
            try:
                shutil.rmtree(j)
            except:continue
    os.chdir(final_output_folder)
    try:
        shutil.rmtree(image_folder)
    except:pass
    try:
        shutil.rmtree(output_folder)
    except:pass
    y = [a for a in os.listdir() if a.endswith(".pdf")]
    result =[]
    if len(y)==len(x):    
        for i in range(len(x)):
                if x[i]==y[i]:
                    filename=y[i]
                    result.append(True)
                else:
                    result.append(False)
    if False in result:return False
    else:return True,Time
