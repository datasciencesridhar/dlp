from win32com.client.dynamic import Dispatch
import pythoncom
import os
def pdf_2_doc(pdf_file):
    pythoncom.CoInitialize()
    word = Dispatch('word.Application')
    word.Visible=False
    input_file = pdf_file
    try:
        wb = word.Documents.Open(input_file,ConfirmConversions=False)
        output_file = os.path.abspath(pdf_file[0:-4])
        wb.SaveAs2(output_file+'.docx')
        print("pdf to word conversion is done.")
        wb.Close()
        word.Quit()
    except:
        print("unabe")
        word.Quit()
