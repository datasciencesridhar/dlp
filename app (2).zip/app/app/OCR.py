import pytesseract
import os

def image_ocr(image_path):   
    os.chdir(image_path)
    
    pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    for filename in os.listdir(image_path):
        if filename.endswith(".jpg"):
            Img =filename
            pdf = pytesseract.image_to_pdf_or_hocr(Img, extension='pdf')
            with open(Img[0:-4]+'.pdf', 'w+b') as f:
               f.write(pdf)
    print('each image is converted to pdf')
