from app import app
from flask import render_template,send_file, send_from_directory,abort
from flask import request, redirect, jsonify, make_response
from werkzeug.utils import secure_filename
from .bookmarking_any_pdf import bookmarker
from zipfile import ZipFile
import pandas as pd
from datetime import date, datetime, timedelta
import datetime
import time
import os
import time
import shutil
from csv import DictWriter


app.config["FILE_UPLOADS"] = "C:/Users/Administrator/Desktop/app/app/static/uploads"
app.config["ALLOWED_IMAGE_EXTENSIONS"] = ["pdf", "PDF"]
app.config["DOWNLOAD_FILES"]="C:/Users/Administrator/Desktop/app/app/static/uploads/downloads"

output_path=''
input_path = ''
downloads = ''

logging = 'C:/Users/Administrator/Desktop/daily_log_details.csv'

feedback = 'C:/Users/Administrator/Desktop/daily_feedback.csv'

def allowed_file(filename):

    if not "." in filename:
        return False

    ext = filename.rsplit(".", 1)[1]

    if ext.upper() in app.config["ALLOWED_IMAGE_EXTENSIONS"]:
        return True
    else:
        return False


def make_archive(file_name):
        global output_path
        global input_path
        global downloads
        try:
            downloads = app.config["DOWNLOAD_FILES"]
            os.mkdir(downloads)
            zipObj = ZipFile(file_name, 'w')
            
            # Add multiple files to the zip
            os.chdir(output_path)
            pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
            for i in pdf_files:
                zipObj.write(i)
            # close the Zip File
            zipObj.close()
        except:pass
        try:   
            src = os.path.abspath(file_name)
            dst = downloads+'//'+file_name
            shutil.move(src,dst)
            os.chdir(input_path)
            
        except:pass

 
@app.route("/download/<file_name>")
def get_files(file_name):

    try:
        return send_from_directory(app.config["DOWNLOAD_FILES"], filename=file_name, as_attachment=True)
    except FileNotFoundError:
        print("nt f")
        abort(404)
        
@app.route("/Download", methods=["GET", "POST"])
def Download():
    global feedback
    if request.method == "POST":

        req = request.form
        feed = req.get("feedback")
        f = {'date':date.today(),'feedback':feed}
        
        isExist = os.path.isfile(feedback)
        if isExist == True:
            field_names = ['date','feedback']
            with open(feedback,'a') as fd:
                dictwriter_object = DictWriter(fd, fieldnames=field_names)
                dictwriter_object.writerow(f)
                fd.close()
        else:
            f = {'date':[date.today()],'feedback':[feed]}
            feedb = pd.DataFrame(f)
            feedb.to_csv(feedback,index=False)

        return redirect(request.url)
    return render_template("Download.html")

        
@app.route("/bookmarking", methods=["GET", "POST"])
def bookmarking():
    global output_path
    global input_path
    global logging
    input_path = app.config["FILE_UPLOADS"]
    os.chdir(input_path)
    pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
    size = [int((os.path.getsize(a))/1024) for a in os.listdir()  if a.endswith(".pdf") ]
    s_no = [b for b in range(len(size))]
    output_path = os.getcwd()+"\\final\\"
    dump = os.getcwd()+"\\dump\\"
    try:
        shutil.rmtree(output_path)
    except:pass
    try:
        shutil.rmtree(dump)
    except:pass
    try:
        os.mkdir(output_path)
    except:pass
    
    try:
        os.mkdir(dump)
    except:pass
    output_folder = dump+"output_folder\\"
    try:
        os.mkdir(output_folder)
    except:pass
    image_folder=dump+"image_folder\\"
    try:
        os.mkdir(image_folder)
    except:pass
    try:
        result, Time = bookmarker(input_path,output_folder,image_folder,output_path)
        os.chdir(output_path)
        print(output_path)
        time.sleep(3)
        result = True
        make_archive('bookmarked_files.zip')
        today = [date.today()]*len(Time)
        log = {'date':today,'file_name':pdf_files,'file_size':size,'time_taken':Time}
        log_details = pd.DataFrame(log)
        isExist = os.path.isfile(logging)
        isExist = os.path.isfile(feedback)
        if isExist == True:
            field_names = ['date','file_name','file_size','time_taken']
            with open(logging,'a') as fd:
                dictwriter_object = DictWriter(fd, fieldnames=field_names)
                dictwriter_object.writerow(log)
                fd.close()
        
        else:
            log_details.to_csv(logging)
            
            

    except:pass
    
    return render_template("bookmarking.html",result=result,s_no_pdf_files_size_Time=zip(s_no,pdf_files,size,Time))



@app.route("/", methods=["GET", "POST"])
def upload_pdf():
    global input_path
    input_path = app.config["FILE_UPLOADS"]
    try:
        os.mkdir(input_path)
    except:pass

    if request.method == "POST":
        
        try:
            for i in os.listdir(input_path):
                try:
                    os.remove(i)
                except:continue
        except:pass

        file = request.files["file"]
        if file.filename == "":
            print("No filename")
            return redirect(request.url)
        
        filename = secure_filename(file.filename)
        
        file.save(os.path.join(input_path, filename))
        
        res = make_response(jsonify({"message": "File uploaded"}), 200)
        return res
    os.chdir(app.config["FILE_UPLOADS"])
    pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]

        

    return render_template("upload.html",pdf_files = pdf_files,num = len(pdf_files))
