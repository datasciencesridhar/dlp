# create a input folder and place the input file 
# create a output folder
# create  a image folder  
# create a final folder
# install tessaract application from this url 
# ( https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-v5.0.0-alpha.20201127.exe )
# Then using pip install  open cv and install pytersseract
# pip install PyMuPDF
# pip install PyPDF2
# pip install pdfminer
import fitz
from win32com.client.dynamic import Dispatch
import pytesseract
import PyPDF2
import pythoncom
import os
import shutil
import time

def Converting_pages_pdf_into_image(input_folder,input_file,image_path):
    os.chdir(input_folder)
    file = input_file
    pdf = fitz.open(file)
    page_count = pdf.pageCount # getting to tal no. of pages in the given pdf
    for j in range(page_count):
        page = pdf.loadPage(j)
        zoom_x = 6.0  # horizontal zoom
        zomm_y = 6.0  # vertical zoom
        mat = fitz.Matrix(zoom_x, zomm_y)  # zoom factor 2 in each dimension
        pix = page.getPixmap(matrix = mat)  # use 'mat' instead of the identity matrix
        new_file = file[0:-4]+'_'+str(j)+'.jpg'
        os.chdir(image_path)
        pix.writeImage(new_file)
    print('pages of pdf are converted as high quality images')
    return input_file

              
def converting_image_to_editable_pdf(image_path):   
    os.chdir(image_path)
    
    pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    for filename in os.listdir(image_path):
        if filename.endswith(".jpg"):
            Img =filename
            pdf = pytesseract.image_to_pdf_or_hocr(Img, extension='pdf')
            with open(Img[0:-4]+'.pdf', 'w+b') as f:
               f.write(pdf)
    print('each image is converted to pdf')

def creating_final_editable_pdf(image_path,output_path,input_file):
    os.chdir(image_path)
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    for pdf in x:
        scale = PyPDF2.PdfFileReader(pdf)
        page = scale.getPage(0)
        page.scaleBy(0.175)
        writer = PyPDF2.PdfFileWriter()  # create a writer to save the updated results
        writer.addPage(page)
        with open(pdf , "wb+") as f:
            writer.write(f)
    
    y = [a for a in os.listdir() if a.endswith(".pdf")]
    merger = PyPDF2.PdfFileMerger()
    for pdf in y:
        merger.append(open(pdf, 'rb'))
    os.chdir(output_path)
    with open(input_file , "wb") as fout:
        merger.write(fout)
        merger.close()
    print('complete editable pdf is created')
    return True
    
def pdf_2_doc(pdf_file):
    pythoncom.CoInitialize()
    word = Dispatch('word.Application')
    word.Visible=False
    input_file = pdf_file
    try:
        wb = word.Documents.Open(input_file,ConfirmConversions=False)
        output_file = os.path.abspath(pdf_file[0:-4])
        wb.SaveAs2(output_file+'.docx')
        print("pdf to word conversion is done.")
        wb.Close()
        word.Quit()
    except:
        print("unabe")
        word.Quit()


def doc_2_pdf(doc_file,doc_name,final_output_folder):
    pythoncom.CoInitialize()
    word = Dispatch('word.Application') # initiation of word application
    word.Visible=False
    input_file = doc_file
    try:
        wb = word.Documents.Open(input_file,ConfirmConversions=False)
        # Please Mentiion the oupout destination path here 
        #/** the destination path should be different fdrom input path**
        
        output_file = final_output_folder +doc_name[0:-5]+'.pdf'
        wb.ExportAsFixedFormat2 (output_file,
                                 ExportFormat=17,
                                 OpenAfterExport=False,
                                 OptimizeFor=0, 
                                 Range=0,
                                 Item=7,
                                 IncludeDocProps=True,
                                 KeepIRM=True,
                                 CreateBookmarks=1,
                                 DocStructureTags=True,
                                 BitmapMissingFonts=True,
                                 UseISO19005_1=True,
                                 OptimizeForImageQuality=True
                                 )
        print("word doc is converted back to pdf formate with bookmarks added .\n")
        wb.Close()
        word.Quit()
    except:
        print("unabe")
        word.Quit()


def pdf_2_pdf(input_file,doc_pdf,final_output_folder):
    pythoncom.CoInitialize()
    word = Dispatch('word.Application') # initiation of word application
    word.Visible=False
    input_file = os.path.abspath(doc_pdf)
    try:
        wb = word.Documents.Open(input_file,ConfirmConversions=False)
        # Please Mentiion the oupout destination path here 
        #/** the destination path should be different fdrom input path**
        output_file = final_output_folder+doc_pdf[0:-4]+'.pdf'
        wb.ExportAsFixedFormat2 (output_file,
                                 ExportFormat=17,
                                 OpenAfterExport=False,
                                 OptimizeFor=0, 
                                 Range=0,
                                 Item=7,
                                 IncludeDocProps=True,
                                 KeepIRM=True,
                                 CreateBookmarks=1,
                                 DocStructureTags=True,
                                 BitmapMissingFonts=True,
                                 UseISO19005_1=True,
                                 OptimizeForImageQuality=True
                                 )
        print("adding bookmarks to the pdf is done.\n")
        wb.Close()
        word.Quit()    
    except:
        word.Quit()
   
def get_pdf_searchable_pages(fname,input_folder,image_folder,output_folder,final_output_folder):
    pythoncom.CoInitialize()
    from pdfminer.pdfpage import PDFPage
    searchable_pages = []
    non_searchable_pages = []
    paths=[]
    page_num = 0
    try:
        with open(fname, 'rb') as infile:
    
            for page in PDFPage.get_pages(infile):
                page_num += 1
                if 'Font' in page.resources.keys():
                    searchable_pages.append(page_num)
                else:
                    non_searchable_pages.append(page_num)
        if page_num > 0:
            if len(non_searchable_pages) == 0:
                print(f'{fname} is a text pdf.')
                pdf_name =fname
                pdf_file = os.path.abspath(pdf_name)
                pdf_2_pdf(pdf_file, pdf_name,final_output_folder)
                os.chdir(input_folder)
                x = [a for a in os.listdir() if a.endswith(".pdf")]
                os.chdir(final_output_folder)
                for filename in os.listdir(final_output_folder):
                    if filename not in x:
                        src = final_output_folder + filename
                        dst = final_output_folder + pdf_name[0:-4]+'.pdf'
                        os.rename(src,dst)
                    else:
                        continue
    
            else:
                print(f"\n{fname} is a scanned pdf.")
                image_path = os.path.join(image_folder , fname[0:-4])
                os.mkdir(image_path)
                output_path = os.path.join(output_folder, fname[0:-4])
                os.mkdir(output_path)
                input_file =fname
                input_file = Converting_pages_pdf_into_image(input_folder,input_file,image_path)
                converting_image_to_editable_pdf(image_path)
                creating_final_editable_pdf(image_path, output_path,input_file)
                os.chdir(input_folder)
                paths.append(image_path)
                paths.append(output_path)
                x = [a for a in os.listdir() if a.endswith(".pdf")]
                os.chdir(output_path)
                y = [a for a in os.listdir() if a.endswith(".pdf")]
                for filename in y:
                        pdf_name =filename
                        pdf_file = os.path.abspath(pdf_name)
                        pdf_2_doc(pdf_file)
                z = [a for a in os.listdir() if a.endswith(".docx")]
                for filename in z:
                        doc_name =filename
                        doc_file = os.path.abspath(doc_name)
                        doc_2_pdf(doc_file, doc_name,final_output_folder)
                        os.chdir(final_output_folder)
                        for filename in os.listdir(final_output_folder):
                            if filename not in x:
                                src = final_output_folder + filename
                                dst = final_output_folder + doc_name[0:-5]+'.pdf'
                                os.rename(src,dst)
                            else:
                                continue
    except:
        pass
    return paths  
                                  
def bookmarker(input_folder,output_folder,image_folder,final_output_folder):
    pythoncom.CoInitialize()    
    os.chdir(input_folder)
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    dump = []
    Time = []
    for filename in x:
        start_time = time.time()
        paths = get_pdf_searchable_pages(filename,input_folder,image_folder,output_folder,final_output_folder)
        dump.append(paths)
        os.chdir(input_folder)
        end_time = time.time()
        total = end_time-start_time
        Time.append(int(total))
    for i in dump:
        for j in i:
            try:
                shutil.rmtree(j)
            except:continue
    os.chdir(final_output_folder)
    try:
        shutil.rmtree(image_folder)
    except:pass
    try:
        shutil.rmtree(output_folder)
    except:pass
    y = [a for a in os.listdir() if a.endswith(".pdf")]
    result =[]
    if len(y)==len(x):    
        for i in range(len(x)):
                if x[i]==y[i]:
                    result.append(True)
                else:
                    result.append(False)
    if False in result:return False
    else:return True,Time
