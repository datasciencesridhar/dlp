"""
    $ python src/main.py
"""

import uvicorn

import config
import server.api as api


def _start_api_server():
    """
    Starts the API server:
    """
    uvicorn.run(
        api.app,
        log_level="info",
        host="0.0.0.0",
        port=config.API_PORT,
    )


if __name__ == "__main__":
    _start_api_server()
