from win32com.client.dynamic import Dispatch
import pythoncom
import os
from publishing.aim_logging.logger import AIMLogging

logger = AIMLogging.getLogger("__name__")


def pdf_2_doc(pdf_file):
    """
    parameters:
    -----------

    pdf_file:
    
    -----------
    Converts pdf to a word document file
    """
    pythoncom.CoInitialize() #setting the parameters so that microsoft word application to work along the flask module.
    word = Dispatch("word.Application") #initialling the microsoft word.
    word.Visible = False #setting the word application to invisible mode.
    input_file = pdf_file
    try:
        wb = word.Documents.Open(input_file, ConfirmConversions=False) #opening the input file using word application and setting the waring message of onconvertion of the file before opening to false.
        output_file = os.path.abspath(pdf_file[0:-4]) #craeting a variable with output file name.
        wb.SaveAs2(output_file + ".docx") # saving the file in .docx format.
        logger.info(f"Pdf to word conversion for given is done.")
    except:
        logger.error(f"Pdf to word conversion failed.")

    wb.Close() #closing the current working filen in word.
    word.Quit() #closing the word application.