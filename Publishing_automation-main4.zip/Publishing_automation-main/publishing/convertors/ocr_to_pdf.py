# Once tesseract extracts text from scanned pdf or image, this function will save it into editable pdf
import os
import PyPDF2
from publishing.aim_logging.logger import AIMLogging

logger = AIMLogging.getLogger(__name__, "INFO")


def _pdf_scaler(pdf_file, SCALE):
    """
    Parameters:
    -----------
    pdf_file:
    
    SCALE:
    -----------
    Scale(?) the given pdf file by factor 'SCALE'
    """
    scale = PyPDF2.PdfFileReader(pdf_file) #opening the pdf file with pypdf2 module.
    page = scale.getPage(0) #getting the dimensions of the page.
    page.scaleBy(SCALE)# scaling the page with the given SCALE dimensions.
    writer = PyPDF2.PdfFileWriter()  # create a writer to save the updated results
    writer.addPage(page)

    logger.info(f"Scaling of pdf {pdf_file} successfully done")
    return writer


def ocr_2_pdf(image_path, output_path, input_file, SCALE=1):
    """
    Parameters:
    -----------
    image_path:

    output_path:

    input_file:

    SCALE:
    -----------
    converts all the images in the image to individual pdf file and then merge all those indivual pdf's into one final editable pdf.
    """
    os.chdir(image_path) #changing the current working directory to the location of the OCFR output.
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    for pdf in x:
        writer = _pdf_scaler(pdf, SCALE) #rescaling the pdf file.
        with open(pdf, "wb+") as f:
            writer.write(f) #updating the pdf file.

    y = [a for a in os.listdir() if a.endswith(".pdf")]
    merger = PyPDF2.PdfFileMerger() #initializing the merger of pypdf2.
    for pdf in y:
        merger.append(open(pdf, "rb")) #adding all the pages to the pdf merger.
    os.chdir(output_path) #changing the current the working directory to temporary output file.
    with open(input_file, "wb") as fout:
        merger.write(fout) #saving the finally merged pdf file.
        merger.close() 
    print("complete editable pdf is created")
    return True
