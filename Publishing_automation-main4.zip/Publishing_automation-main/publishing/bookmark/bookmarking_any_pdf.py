"""
# create a input folder and place the input file
# create a output folder
# create  a image folder
# create a final folder
# install tessaract application from this url
# ( https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-v5.0.0-alpha.20201127.exe )
# Then using pip install  open cv and install pytersseract
# fitz is used for accessing python scripts with pdf file extensions
"""
import fitz

# win32com is used here for extracting bookmarks by dispatchig MS word. Tried python docx, but it unable to access word files.
from win32com.client.dynamic import Dispatch

# Pytesseract is for Optical Charecter Recognition
import pytesseract
import PyPDF2
import pythoncom
import os
import shutil
import time

# reportlab is used for TOC generation
from reportlab.pdfgen import canvas
from reportlab.lib import pdfencrypt

from .PDF_TO_IMAGE import pdf_pages_2_image
from .OCR import image_ocr
from .OCR_TO_PDF import ocr_2_pdf
from .PDF_TO_DOC import pdf_2_doc
from .DOC_TO_PDF_BOOKMARKER import doc_2_pdf_bookmarker
from .PDF_TO_PDF_BOOKMARKER import pdf_2_pdf_bookmarker
from .TOC import creating_table_of_contents


def get_pdf_searchable_pages(fname, input_folder, image_folder, output_folder, final_output_folder, toc_folder):
    """
    parameters:
    --------------
    filaname:
    
    input_folder:

    image_folder:

    output_folder:

    final_output_folder:

    toc_folder:
    ----------------
    Pdfminer converts non-editable pdf to editable pdf and if it recognize any font(text) in the
    output. It prints it as text pdf. If it unable to find the font(text) it identifies it as
    scanned pdf/image.If scanned pdf/image is found it initiates tesseract for OCR.
    """
    pythoncom.CoInitialize() #initiallizing the pdfminner and other modules used here to work along the flask module.
    from pdfminer.pdfpage import PDFPage

    searchable_pages = [] #list to get no. of searchable pages meaning where the text if found. 
    non_searchable_pages = [] #list to get no. of non searchable pages mean where no text/font is detected.
    paths = [] # list used for the collecting loactions of all the temp files.
    page_num = 0 #setting the initial page number to zero.
    try:
        with open(fname, "rb") as infile:

            for page in PDFPage.get_pages(infile):
                page_num += 1 #updating the page no. 
                if "Font" in page.resources.keys():  # chacking for the font in the page.
                    searchable_pages.append(page_num) # if the font found then updating the serachble_page list with the page no.
                else:
                    non_searchable_pages.append(page_num) #if the font is not found then updating the non_serachble_page list with the page no.
        if page_num > 0:
            if len(non_searchable_pages) == 0:
                print(f"{fname} is a text pdf.")
                pdf_name = fname
                pdf_file = os.path.abspath(pdf_name) # getting the input file name along with it's absolute path.
                temp_folder = os.path.join(toc_folder, fname[0:-4] + "//") # initializing a variable iwth temp folder name and path.
                os.mkdir(temp_folder) #creting the temp folder
                print(temp_folder) #confirming the temp folder created.
                paths.append(temp_folder) #updating the list with the temp folder location.
                pdf_2_pdf_bookmarker(pdf_name, pdf_name, temp_folder) # passing the text pdf for bookmarking and saving as pdf.
                os.chdir(temp_folder) #changing the current working directory to temp folder.
                creating_table_of_contents(temp_folder, pdf_name) #creating the TOC of the bookmarked pdf.
                # the output pdf after the TOC being added will loose all it's bookmarks.
                pdf_2_pdf_bookmarker(fname, fname, final_output_folder) #so again adding the bookmarks and saving it as pdf with original input file name. 
                os.chdir(input_folder) #changing the current working directory to the input file location.
                x = [a for a in os.listdir() if a.endswith(".pdf")] # getting the list of all the uploaded pdf's.
                os.chdir(final_output_folder) #changing the current working directory to final output loaction.
                for filename in os.listdir(final_output_folder):
                    if filename not in x:
                        #reconfirming/renaming the the final output file names with the originally uploaded file names.
                        src = final_output_folder + filename
                        dst = final_output_folder + pdf_name[0:-4] + ".pdf"
                        os.rename(src, dst)
                    else:
                        continue

            else:
                print(f"\n{fname} is a scanned pdf.")  # confirming that the input file as scanned pdf.
                image_path = os.path.join(image_folder, fname[0:-4]) #initiallizing tne path of the temp folder named image for input file of tesseract for OCR.
                os.mkdir(image_path) # creating the temporary image folder.
                output_path = os.path.join(output_folder, fname[0:-4])#initiallizing tne path of the temp folder named output for final ouput folder of OCR files.
                os.mkdir(output_path)# creating the tempoirary output folder.
                input_file = fname # inpiut variable initializing  with the name of the current working pdf file name.
                input_file = pdf_pages_2_image(input_folder, input_file, image_path) #converting each page of the scanned pdf into a high quality-zoomed images. 
                image_ocr(image_path) #performing the OCR on tghe induvidalu images of the pdf.
                ocr_2_pdf(image_path, output_path, input_file, 0.175) # all the OCR output files are merged into one single editable pdf file.
                os.chdir(input_folder) #changing the current working to input file loaction.
                paths.append(image_path) #updating the list with the temp folder location.
                paths.append(output_path) #updating the list with the temp folder location.
                x = [a for a in os.listdir() if a.endswith(".pdf")] #getting the name of the uploaded files.
                os.chdir(output_path) #changing the current working directory to the temp output folder.
                y = [a for a in os.listdir() if a.endswith(".pdf")] #getting the names of the final OCR output file.
                for filename in y:
                    pdf_name = filename
                    pdf_file = os.path.abspath(pdf_name) #getting output file name of the OCR output along with full absolute path of the file.
                    pdf_2_doc(pdf_file) #converting the OCR output pdf file to .docx file using microsoft word application.
                z = [a for a in os.listdir() if a.endswith(".docx")] #getting the list of the .docx files in the current working directory which is the output folder of pdf_2_doc function.
                for filename in z:
                    doc_name = filename
                    doc_file = os.path.abspath(doc_name) #getting output file name of the pdf_2_doc funtion along with full absolute path of the file.
                    temp_folder = os.path.join(toc_folder, fname[0:-4] + "//") #initialling a temporary folder with current working file name. 
                    os.mkdir(temp_folder) #creating the temp folderr with the current file name.
                    print(temp_folder) #confirmimg the temp folder name and location.
                    doc_2_pdf_bookmarker(doc_file, doc_name, temp_folder) #adding bookmarks to the input .docx file using microsoft word application saving it as .pdf file in the temp folder created by it's name.
                    os.chdir(temp_folder) #chaning the current working directory to the temp folder created with current working file name.
                    creating_table_of_contents(temp_folder, fname) #creating the TOC of the bookmarked pdf.
                    # the output pdf after the TOC being added will loose all it's bookmarks.
                    pdf_2_pdf_bookmarker(fname, fname, final_output_folder) #so again adding the bookmarks and saving it as pdf with original input file name.
                    os.chdir(final_output_folder) #changing the current working directory to final output loaction.
                    for filename in os.listdir(final_output_folder):
                        if filename not in x:
                            #reconfirming/renaming the the final output file names with the originally uploaded file names.
                            src = final_output_folder + filename
                            dst = final_output_folder + doc_name[0:-5] + ".pdf"
                            os.rename(src, dst)
                        else:
                            continue
    except:
        pass
    return paths


def bookmarker(input_folder, output_folder, image_folder, final_output_folder, toc_folder):
    '''
    Parameters:
    -------------------
    input_folder:
    
    output_folder:
    
    image_folder:
    
    final_output_folder:
    
    toc_folder:
    --------------------
    function used for adding bookmarks to a given input pdf file.
    '''
    pythoncom.CoInitialize() #innitiallizing the bookmarker with to work along with flask application.
    os.chdir(input_folder) # changing the current working directory to the input file location.
    x = [a for a in os.listdir() if a.endswith(".pdf")] #getting the list of pdf file been uploaded to the pdf bookmarker.
    dump = [] # list to get the info on all the temp files creted while bookmarking a file.
    Time = [] # list to get the info on time take for the adding bookmarks to the given input file.
    for filename in x:
        start_time = time.time() #noted the start time of thge bookmarking.
        paths = get_pdf_searchable_pages(
            filename,
            input_folder,
            image_folder,
            output_folder,
            final_output_folder,
            toc_folder,
        ) # passing the pdf file along with file location and fuinal output location and some temp file locations for adding the bookmarks to the pdf.
        dump.append(paths) #updatin the list with all the temp file paths.
        os.chdir(input_folder) #change the working directory to the input file location for the next pdf file.
        end_time = time.time() # noted the end time of the bookmerking of the given pdf file.
        total = end_time - start_time # calculated the total time taken to complete the bookmarking of the current file.
        Time.append(int(total)) #updated the list with the total time taken for the current file. 
    for i in dump:
        for j in i:
            try:
                shutil.rmtree(j) #removing all the temp files that has been created along the process.
            except:
                continue
    os.chdir(final_output_folder) #changing the current working directory to final output file location
    try:
        shutil.rmtree(image_folder) #removing all the image file used for the OCR.
    except:
        pass
    try:
        shutil.rmtree(output_folder) # removing the temp output file of the OCR.
    except:
        pass
    y = [a for a in os.listdir() if a.endswith(".pdf")] # getting the list of pdf files in the final destination.
    result = [] # list to verify if all the file have been converted sucessfully.
    if len(y) == len(x):
        for i in range(len(x)):
            if x[i] == y[i]:
                #checking if the name of the input and the final output file is same or not. 
                result.append(True)
            else:
                result.append(False)
    if False in result:
        return False
    else:
        return True, Time
