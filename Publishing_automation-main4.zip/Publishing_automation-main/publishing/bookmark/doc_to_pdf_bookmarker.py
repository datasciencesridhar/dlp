from win32com.client.dynamic import Dispatch
import pythoncom
import os


def doc_2_pdf_bookmarker(doc_file, doc_name, final_output_folder):
    '''
    coverting a .docx file to a .pdf file using the microsoft office word application and making all the heading as bookmarks of the pdf.
    '''
    pythoncom.CoInitialize() #initializing the win32 application to work along the flask module.
    word = Dispatch("word.Application")  # initiation of word application
    word.Visible = False # setting the word application to invisible mode.
    input_file = doc_file
    try:
        wb = word.Documents.Open(input_file, ConfirmConversions=False) #opening the .docx file with the word application using win32
        # Please Mentiion the oupout destination path here
        # /** the destination path should be different from input path**

        output_file = final_output_folder + doc_name[0:-5] + ".pdf" #declearing the output file name.
        #setting all the parameters of the output file using the ExportAsFixedFormat2 function provided by the microsoft word api and saving as .pdf file.
        wb.ExportAsFixedFormat2(
            output_file,
            ExportFormat=17,
            OpenAfterExport=False,
            OptimizeFor=0,
            Range=0,
            Item=7,
            IncludeDocProps=True,
            KeepIRM=True,
            CreateBookmarks=1,
            DocStructureTags=True,
            BitmapMissingFonts=True,
            UseISO19005_1=True,
            OptimizeForImageQuality=True,
        )
        print("word doc is converted back to pdf formate with bookmarks added .\n")
        wb.Close() #closing the .docx file.
        word.Quit()#closing the word application.
    except:
        print("unabe")
        word.Quit()
