"""
Main logging module
"""

import logging
from publishing import config
from typing import Union, Optional
from publishing.aim_logging.logging_level import LogLevel
from publishing.aim_logging.logging_handler import LoggingHandler


class AIMLogging:
    """
    >>> import AIMLogging
    >>> logger = AIMLogging.getLogger(__name__, 'INFO')
    """

    @staticmethod
    def getLogger(name: str, level: Optional[Union[str, int]] = None):
        logger = logging.getLogger(name)
        if level:
            logger.setLevel(LogLevel.from_string(str(level)))

        if not AIMLogging._check_handler_set():
            logger.addHandler(
                LoggingHandler(config.LOG_FILE, config.MAX_BYTES, config.BACKUP_COUNT)
            )

        return logger

    @staticmethod
    def _check_handler_set() -> bool:
        logger = logging.getLogger()
        return any([isinstance(hdlr, LoggingHandler) for hdlr in logger.handlers])
