from datetime import datetime, timezone, timedelta
import json
from time import localtime
import logging
from publishing.aim_logging.logging_level import LogLevel


class LoggingFormatter(logging.Formatter):
    """"""

    ALLOWED_LEVELS = [level.value for level in LogLevel]

    def __init__(self):
        """"""
        super().__init__(
            fmt='{"timestamp":"%(asctime)s","thread":"%(threadName)s",'
            '"level":"%(levelname)s","logger":"%(pathname)s:%(lineno)d",'
            '"message":%(message)s}',
            datefmt="%Y-%m-%dT%H:%M:%S",
            style="%",
        )

    def format(self, record):
        """"""
        if record.levelno not in self.ALLOWED_LEVELS:
            record.msg = f"LOG REDIRECTED FROM '{record.levelname}': {record.msg}"
            record.levelname = "INFO"
            record.levelno = LogLevel.INFO.value

        if record.exc_info:
            record.msg = ", ".join(
                [record.msg, repr(super().formatException(record.exc_info))]
            )
            record.exc_info = False
            record.exc_text = None
        record.msg = json.dumps(record.msg, default=str)
        return super().format(record)
