"""
Formatting logging file handler
"""
from logging.handlers import RotatingFileHandler
import sys
import publishing.config
from publishing.aim_logging.logging_formatter import LoggingFormatter


class LoggingHandler(RotatingFileHandler):
    """
    Logging FileHandler that makes use of the logging Formatter
    """

    def __init__(self, filename, maxBytes, backupCount):
        super().__init__(filename, maxBytes, backupCount)
        self.setFormatter(LoggingFormatter())
