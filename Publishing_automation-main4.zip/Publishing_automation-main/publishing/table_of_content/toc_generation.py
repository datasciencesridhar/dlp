# using reportlab library bookmarks will be saved as TOC at first page of the PDF
import PyPDF2
import fitz
import os
import time
from reportlab.pdfgen import canvas
from reportlab.lib import pdfencrypt
from reportlab.platypus import PageBreak
from textwrap import wrap

def creating_final_editable_pdf(input_path, input_file):
    '''
    Parameters:
    -----------
    input_path:

    input_file:
    -----------
    creating a single TOC file by mergging all the each page toc pdf's and then finally
    givng the output pdf file with TOC added to the original input file.
    '''
    # pythoncom.CoInitialize()
    os.chdir(input_path)
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    x.sort()
    print(x)
    writer = PyPDF2.PdfFileWriter()  # create a writer to save the updated results
    file = input_file
    print("\n", file)

    for i in x:
        if i != file:
            pdf = fitz.open(i)
            page_count = pdf.pageCount
            # pdf.close()
            scale = PyPDF2.PdfFileReader(i)
            print("\n", page_count, "\n")
            for j in range(page_count):
                # print(j)
                page = scale.getPage(j)
                writer.addPage(page)
    with open("toc.pdf", "wb+") as f:
        writer.write(f)
    f.close()
    writer1 = PyPDF2.PdfFileWriter()
    pdf = fitz.open("toc.pdf")
    page_count1 = pdf.pageCount
    
    scale1 = PyPDF2.PdfFileReader("toc.pdf")
    print("\n", page_count, "\n")
    pdf0 = fitz.open(file)
    page_count = pdf0.pageCount
    
    print("\n", page_count, "\n")
    scale = PyPDF2.PdfFileReader(file)
    count = 0
    for jj in range(page_count):
        # print(j)
        if count == 0:
            for j in range(page_count1):
                # print(j)
                page = scale1.getPage(j)
                writer1.addPage(page)
            count += 1
        page = scale.getPage(jj)
        writer1.addPage(page)
    with open(file, "wb+") as f:
        writer1.write(f)
    f.close()

    time.sleep(1)
    # os.remove("0.pdf")
    print("Table of Contents is added to the pdf.")


def _setup_page_id_to_num(pdf, pages=None, _result=None, _num_pages=None):
    '''
    Parameters:
    -------------------
    pdf:

    pages=None

    _result=None

    _num_pages=None
    -------------------
    getting the page numbers of the bookmarks in the pdf file.
    '''
    if _result is None:
        _result = {}
    if pages is None:
        _num_pages = []
        pages = pdf.trailer["/Root"].getObject()["/Pages"].getObject()
    t = pages["/Type"]
    if t == "/Pages":
        for page in pages["/Kids"]:
            _result[page.idnum] = len(_num_pages)
            _setup_page_id_to_num(pdf, page.getObject(), _result, _num_pages)
    elif t == "/Page":
        _num_pages.append(1)
    return _result


def toc_page(pd, bookmarks, pagenum, w, h, pg, ii, g):
    '''
    creating each page of the TOC and saving the page as pdf with name as the page number.
    '''
    pdf = canvas.Canvas(pd, bottomup=0, pagesize=(w, h)) #creating a pdf file and setting the text input to start from the top of the page.
    if pd == "0.pdf":
        pdf.drawString(30, 20, "Table Of Contents") # inserting the heading as TOC if the paf file is the first page of TOC.
    c = 50
    ac = "........"
    lines = 0
    rr = True
    j = bookmarks
    try:
        for ii in range(len(j)):
            x = 0
            y = 32
            if lines == 23:
                rr = True
                break
            if type(j[ii]) is list:
                y += 10
                if len(j[ii]) >= 1:
                    while g in range(len(j[ii])):
                        pdf.drawString(y, c, j[ii][g] + ac + " " + str(pagenum[pg])) #inserting the second level bookmarks with page numbers in TOC.
                        c += 30
                        pg += 1
                        g += 1
                        lines += 1
                    ii += 1

            else:
                pdf.drawString(y, c, j[ii] + ac + " " + str(pagenum[pg])) #inserting the bookmarks with page numbers in the TOC.
                c += 30
                lines += 1
                pg += 1
                ii += 1
        pdf.save() #saving the page of the TOC as a pdf.
        return [rr, pg, ii, g]
    except IndexError:
        rr = False
        return [rr, pg, ii, g]


def creating_table_of_contents(input_path, input_file):
    '''
    Parameters:
    -------------------
    input_path:

    input_file:
    -------------------
    funtion used for creation of table of contents using all the bookmarks
    available in the given input pdf file.
    '''
    # pythoncom.CoInitialize()
    os.chdir(input_path) #change the currernt working directory to the pdf file location.
    doc = fitz.open(input_file) #opening the pdf file using fitz module.
    page = doc.loadPage(0) #loading the first page of the pdf.
    a = page.MediaBox #getting the dimensions of the pdf page file.
    w = a[2] #getting the width of the page.
    h = a[3] #getting the height of the page.
    doc.close() #closing the pdf file.
    print(input_path) #confirming the current working directory.
    print("\n", input_file) # confirming the current working pdf file name.
    f = open(input_file, "rb") #opening the inout file in reading binary mode.
    p = PyPDF2.PdfFileReader(f) #the binary mode fileis opened/passed to the pdfereader.
    pg_id_num_map = _setup_page_id_to_num(p) # mapping page ids to page numbers.
    o = p.getOutlines() #getting the bookmarks of the pdf.
    pg_num = pg_id_num_map[o[0].page.idnum] + 1 #declaring the page number of the first page as 1.
    bookmarks = [] #declearing a empty bookmarks list.
    #updating the bookmarks list with a two level bookmarks.
    for i in range(len(o)):
        if len(o[i]) == 6:
            try:
                bookmarks.append(o[i].title)
            except:
                pass
        else:
            aa = []
            for j in o[i]:
                if len(j) == 6:
                    try:
                        aa.append(j.title)
                    except:
                        pass
                else:
                    for a in j:
                        if len(a) == 6:
                            try:
                                aa.append(a.title)
                            except:
                                pass
                        else:
                            for b in a:
                                if len(b) == 6:
                                    try:
                                        aa.append(b.title)
                                    except:
                                        pass
                                else:
                                    try:
                                        for c in b:
                                            if len(c) == 6:
                                                aa.append(c.title)
                                    except:
                                        pass

            try:
                bookmarks.append(aa)
            except:
                pass

    pagenum = [] #declearing a empty bookmarks list.
    #updating the pagenum list with page numbers in respective to bookmarks.
    for i in range(len(o)):
        if len(o[i]) == 6:
            try:
                pagenum.append(pg_id_num_map[o[i].page.idnum] + 1)
            except:
                pass
        else:
            for j in o[i]:
                if len(j) == 6:
                    try:
                        pagenum.append(pg_id_num_map[j.page.idnum] + 1)
                    except:
                        pass
                else:
                    for a in j:
                        if len(a) == 6:
                            try:
                                pagenum.append(pg_id_num_map[a.page.idnum] + 1)
                            except:
                                pass
                        else:
                            for b in a:
                                if len(b) == 6:
                                    try:
                                        pagenum.append(pg_id_num_map[b.page.idnum] + 1)
                                    except:
                                        pass
                                else:
                                    try:
                                        for c in b:
                                            if len(c) == 6:
                                                pagenum.append(
                                                    pg_id_num_map[c.page.idnum] + 1
                                                )
                                    except:
                                        pass

    f.close() # closing the pdf file.
    #craeting a few dummy variables for saving the each page of table of contents. 
    aa = 0
    pg = 0
    ii = 0
    g = 0
    while True:
        pd = str(aa) + ".pdf" #creating the pdf name for the each page of TOC
        fg = toc_page(pd, bookmarks, pagenum, w, h, pg, ii, g) # creatiung the page of TOC.
        print(pd)
        aa += 1
        try:
            # updating the dummy variables for thge next page of the TOC.
            result = fg[0]
            pg = fg[1]
            ii = fg[2]
            g = fg[3]
            print(len(bookmarks)) #checking the number of remaning bookmarks.
        except:
            pass
        time.sleep(1)
        if result == False:
            # if all the pages of the TOC are craeted then the loop is breaked.
            break
    creating_final_editable_pdf(input_path, input_file) # crdeating a final pdf file out with attaching the TOC in the top of the pdf.
