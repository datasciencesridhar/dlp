"""
Unit test cases for utility functions
"""
import pytest
from publishing.utils.utils import supported_file_type


@pytest.mark.parametrize(
    "inputfile, support",
    [
        ("test_file.pdf", True),
        ("test_file.PDF", True),
        ("test_file.pDf", True),
        ("test_file.txt", False),
        (None, False),
        ("test_file", False),
        ("test_file.", False),
    ],
)
def test_supported_file_type_success(inputfile, support):
    assert supported_file_type(inputfile) == support
