"""
Unit tests for logger
"""
import json
import logging
from publishing import config
from testfixtures import TempDirectory, compare
from publishing.aim_logging.logger import AIMLogging
from publishing.aim_logging.logging_handler import LoggingHandler


def get_handler_from_logger(logger: logging.Logger):
    """"""
    for hdlr in logger.handlers:
        if isinstance(hdlr, LoggingHandler):
            return hdlr


def test_logger(caplog):
    """"""

    logger = AIMLogging.getLogger(__name__)
    with caplog.at_level(logging.DEBUG):
        caplog.clear()
        file_length_before = file_len(config.LOG_FILE)
        logger.debug("Test log")
        file_length_after = file_len(config.LOG_FILE)

    assert file_length_after == file_length_before + 1


def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1