from app import app
from flask import render_template,send_file, send_from_directory,abort
from flask import request, redirect, jsonify, make_response
from werkzeug.utils import secure_filename
from .bookmarking_any_pdf import bookmarker
from zipfile import ZipFile
import pandas as pd
from datetime import date, datetime, timedelta
import datetime
import time
import os
import shutil
from csv import DictWriter

file_upload = os.getcwd() + "/app/static/uploads/"
file_download = file_upload + "downloads"

app.config["FILE_UPLOADS"] = file_upload
app.config["ALLOWED_IMAGE_EXTENSIONS"] = ["pdf", "PDF"]


output_path=''
input_path = ''
downloads = ''

logging = os.getcwd()+'/logs/daily_log_details.csv'

feedback = os.getcwd()+'/feedback/daily_feedback.csv'

def allowed_file(filename):

    if not "." in filename:
        return False

    ext = filename.rsplit(".", 1)[1]

    if ext.upper() in app.config["ALLOWED_IMAGE_EXTENSIONS"]:
        return True
    else:
        return False


def make_archive(file_name):
    global output_path
    global input_path
    global downloads
    downloads = app.config["DOWNLOAD_FILES"]
    aaa=os.getcwd()
    try:
        os.chdir(downloads)
        pdf_files = [a for a in os.listdir() if a.endswith(".zip") or a.endswith(".ZIP")]
        for i in pdf_files:
            try:os.remove(i)
            except:continue
    except:pass
    os.chdir(aaa)
    try:
        os.mkdir(downloads)
    except:pass
    try:
        zipObj = ZipFile(file_name, 'w')
        
        # Add multiple files to the zip
        os.chdir(output_path)
        pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
        for i in pdf_files:
            zipObj.write(i)
        # close the Zip File
        zipObj.close()
    except:pass
    try:   
        src = os.path.abspath(file_name)
        dst = downloads+'//'+file_name
        shutil.move(src,dst)
        os.chdir(input_path)
        
    except:pass

 
@app.route("/download/<file_name>")
def get_files(file_name):
    global input_path
    a=os.getcwd()
    try:
        os.chdir(input_path)
        pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
        for i in pdf_files:
            try:os.remove(i)
            except:continue
    except:pass
    os.chdir(a)
    try:
        return send_from_directory(app.config["DOWNLOAD_FILES"], filename=file_name, as_attachment=True)
    except FileNotFoundError:
        print("nt f")
        abort(404)
        
@app.route("/Download", methods=["GET", "POST"])
def Download():
    global feedback
    global input_path
    aa=os.getcwd()
    try:
        os.chdir(input_path)
        pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
        for i in pdf_files:
            try:os.remove(i)
            except:continue
    except:pass
    os.chdir(aa)

    if request.method == "POST":
        try:
            req = request.form
            output_folder = req.get("output_path")
            print(output_folder)
            app.config["DOWNLOAD_FILES"]=output_folder
            make_archive('bookmarked_files.zip')
        except:pass
        try:
            req = request.form
            feed = req.get("feedback")
            f = {'date':date.today(),'feedback':feed}
            
            isExist = os.path.isfile(feedback)
            if isExist == True:
                field_names = ['date','feedback']
                with open(feedback,'a') as fd:
                    dictwriter_object = DictWriter(fd, fieldnames=field_names)
                    dictwriter_object.writerow(f)
                    fd.close()
            else:
                f = {'date':[date.today()],'feedback':[feed]}
                feedb = pd.DataFrame(f)
                feedb.to_csv(feedback,index=False)

            return redirect(request.url)
        except:pass
    return render_template("Download.html")

        
@app.route("/bookmarking", methods=["GET", "POST"])
def bookmarking():
    global output_path
    global input_path
    global logging
    input_path = app.config["FILE_UPLOADS"]
    os.chdir(input_path)
    pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
    size = [int((os.path.getsize(a))/1024) for a in os.listdir()  if a.endswith(".pdf") ]
    s_no = [b for b in range(len(size))]
    output_path = os.getcwd()+"\\final\\"
    dump = os.getcwd()+"\\dump\\"
    toc_folder = os.getcwd()+"\\toc_file\\"
    try:
        shutil.rmtree(output_path)
    except:pass
    try:
        shutil.rmtree(dump)
    except:pass
    try:
        shutil.rmtree(toc_folder)
    except:pass
    try:
        os.mkdir(output_path)
    except:pass
    
    try:
        os.mkdir(dump)
    except:pass
    try:
        os.mkdir(toc_folder)
    except:pass
    output_folder = dump+"output_folder\\"
    try:
        os.mkdir(output_folder)
    except:pass
    image_folder=dump+"image_folder\\"
    try:
        os.mkdir(image_folder)
    except:pass
    try:
        result, Time = bookmarker(input_path,output_folder,image_folder,output_path,toc_folder)
        os.chdir(output_path)
        print(output_path)
        time.sleep(3)
        result = True
        
        today = [date.today()]*len(Time)
        log = {'date':today,'file_name':pdf_files,'file_size':size,'time_taken':Time}
        log_details = pd.DataFrame(log)
        isExist = os.path.isfile(logging)
        isExist = os.path.isfile(feedback)
        if isExist == True:
            field_names = ['date','file_name','file_size','time_taken']
            with open(logging,'a') as fd:
                dictwriter_object = DictWriter(fd, fieldnames=field_names)
                dictwriter_object.writerow(log)
                fd.close()
        
        else:
            log_details.to_csv(logging)
            
            

    except:pass
    
    return render_template("bookmarking.html",result=result,s_no_pdf_files_size_Time=zip(s_no,pdf_files,size,Time))



@app.route("/", methods=["GET", "POST"])
def upload_pdf():
    global input_path
    input_path = app.config["FILE_UPLOADS"]
    try:
        os.mkdir(input_path)
    except:pass

    if request.method == "POST":
        
        try:
            for i in os.listdir(input_path):
                try:
                    if os.path.isfile(i)!=True:
                        os.remove(i)
                except:continue
        except:pass

        file = request.files["file"]
        if file.filename == "":
            print("No filename")
            return redirect(request.url)
        
        filename = secure_filename(file.filename)
        
        file.save(os.path.join(input_path, filename))
        
        res = make_response(jsonify({"message": "File uploaded"}), 200)
        
        return res
        

    return render_template("upload.html")
