# when def:get_pdf_searchable_pages identifies input doc as scanned pdf or image. This function gets initiated. Pytesseract is a python binder used for OCR
import pytesseract
import os
from publishing.aim_logging.logger import AIMLogging

logger = AIMLogging.getLogger(__name__, "INFO")


def convert_images_to_pdf(image_dir):
    """
    Loops over the files in the given image dir and convert the supported files to pdfs.
    """
    full_path = os.path.abspath(image_path)

    for image_file in os.listdir(full_path):
        if image_file.endswith(".jpg"):
            pdf = _convert_jpg_to_pdf(image_file)
            if pdf:
                with open(Img[0:-4] + ".pdf", "w+b") as f:
                    f.write(pdf)
        else:
            logger.info(
                f"Only jpg conversion to pdf is suported. {image_file} is not of type of jpg."
            )
    logger.debug("Image files conversion to pdf done.")


def _convert_jpg_to_pdf(image_file):
    """
    Takes jpg image and converts it to pdf
    """
    pytesseract.pytesseract.tesseract_cmd = "tesseract"

    try:
        pdf = pytesseract.image_to_pdf_or_hocr(image_file, extension="pdf")
    except OSError as error:
        logger.info(f"Conversion of image {image_file} failed", exc_info=error)
        return None

    logger.info(f"Conversion of image {image_file} successfully done")
    return pdf
