# when any scanned pdf or image file is identified, this function using fitz library converts each unique scanned pdf page into a separate image and it will be zoomed to 6/6 range inorder to improve OCR output.
import fitz
import os


def pdf_pages_2_image(input_folder, input_file, image_path):
    os.chdir(input_folder)
    file = input_file
    pdf = fitz.open(file)
    page_count = pdf.pageCount  # getting to tal no. of pages in the given pdf
    for j in range(page_count):
        page = pdf.loadPage(j)
        zoom_x = 6.0  # horizontal zoom
        zomm_y = 6.0  # vertical zoom
        mat = fitz.Matrix(zoom_x, zomm_y)  # zoom factor 2 in each dimension
        pix = page.getPixmap(matrix=mat)  # use 'mat' instead of the identity matrix
        new_file = file[0:-4] + "_" + str(j) + ".jpg"
        os.chdir(image_path)
        pix.writeImage(new_file)
    print("pages of pdf are converted as high quality images")
    return input_file
