# Once tesseract extracts text from scanned pdf or image, this function will save it into editable pdf
import os
import PyPDF2
from publishing.aim_logging.logger import AIMLogging

logger = AIMLogging.getLogger(__name__, "INFO")


def _pdf_scaler(pdf_file, SCALE):
    """
    Scale(?) the given pdf file by factor 'SCALE'
    """
    scale = PyPDF2.PdfFileReader(pdf_file)
    page = scale.getPage(0)
    page.scaleBy(SCALE)
    writer = PyPDF2.PdfFileWriter()  # create a writer to save the updated results
    writer.addPage(page)

    logger.info(f"Scaling of pdf {pdf_file} successfully done")
    return writer


def ocr_2_pdf(image_path, output_path, input_file, SCALE=1):
    """
    Parameters:
    -----------
    image_path:

    output_path:

    input_file:

    SCALE:
    """
    os.chdir(image_path)
    x = [a for a in os.listdir() if a.endswith(".pdf")]
    for pdf in x:
        writer = _pdf_scaler(pdf, SCALE)
        with open(pdf, "wb+") as f:
            writer.write(f)

    y = [a for a in os.listdir() if a.endswith(".pdf")]
    merger = PyPDF2.PdfFileMerger()
    for pdf in y:
        merger.append(open(pdf, "rb"))
    os.chdir(output_path)
    with open(input_file, "wb") as fout:
        merger.write(fout)
        merger.close()
    print("complete editable pdf is created")
    return True
