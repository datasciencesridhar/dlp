# In order to extract bookmarks from a non-editable pdf, first it has to get converted to editable word. This happens at this step. Once pdf is converted to word. Bookmarking process gets started
from win32com.client.dynamic import Dispatch
import pythoncom
import os
from publishing.aim_logging.logger import AIMLogging

logger = AIMLogging.getLogger("__name__")


def pdf_2_doc(pdf_file):
    """
    Converts pdf to a word document file
    """
    pythoncom.CoInitialize()
    word = Dispatch("word.Application")
    word.Visible = False
    input_file = pdf_file
    try:
        wb = word.Documents.Open(input_file, ConfirmConversions=False)
        output_file = os.path.abspath(pdf_file[0:-4])
        wb.SaveAs2(output_file + ".docx")
        logger.info(f"Pdf to word conversion for given is done.")
    except:
        logger.error(f"Pdf to word conversion failed.")

    wb.Close()
    word.Quit()