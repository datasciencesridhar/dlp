"""
Module for parsing allowed logging levels
"""
from enum import Enum
import logging


class LogLevel(Enum):
    """
    Logging level supported log levels.
    """

    DEBUG = logging.DEBUG
    INFO = logging.INFO
    ERROR = logging.ERROR

    @staticmethod
    def from_string(level: str = "INFO") -> int:
        """
        Parse logging level from string
        """
        level = level.upper()
        if level in ("INFO", "1"):
            loglevel = logging.INFO
        elif level in ("ERROR", "2"):
            loglevel = logging.ERROR
        elif level in ("DEBUG", "0"):
            loglevel = logging.DEBUG
        else:
            raise ValueError("Logging level is not [DEBUG (0), INFO (1), ERROR (2)]")

        return loglevel
