from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


class InputForm(FlaskForm):
    input_path = StringField("path of the input folder", validators=[DataRequired()])
    output_path = StringField("path of the input folder", validators=[DataRequired()])
    submit = SubmitField("Submit")
