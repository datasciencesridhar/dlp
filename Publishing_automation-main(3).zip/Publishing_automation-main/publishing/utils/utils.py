import os
from publishing import config


def supported_file_type(filename: str) -> bool:
    """
    Utility function to check if the input file extension is supoprted.
    """
    if (not filename) or (not "." in filename):
        return False

    extension = filename.rsplit(".", 1)[1]

    if extension.upper() in config.SUPPORTED_IMAGE_EXTENSIONS:
        return True

    return False


def make_archive(file_name):
    global output_path
    global input_path
    global downloads
    downloads = app.config["DOWNLOAD_FILES"]
    aaa = os.getcwd()
    try:
        os.chdir(downloads)
        pdf_files = [
            a for a in os.listdir() if a.endswith(".zip") or a.endswith(".ZIP")
        ]
        for i in pdf_files:
            try:
                os.remove(i)
            except:
                continue
    except:
        pass
    os.chdir(aaa)
    try:
        os.mkdir(downloads)
    except:
        pass
    try:
        zipObj = ZipFile(file_name, "w")

        # Add multiple files to the zip
        os.chdir(output_path)
        pdf_files = [a for a in os.listdir() if a.endswith(".pdf")]
        for i in pdf_files:
            zipObj.write(i)
        # close the Zip File
        zipObj.close()
    except:
        pass
    try:
        src = os.path.abspath(file_name)
        dst = downloads + "//" + file_name
        shutil.move(src, dst)
        os.chdir(input_path)

    except:
        pass
