# API:
API_PORT = 9999

# Uploading
SUPPORTED_IMAGE_EXTENSIONS = ["PDF"]

# Logging:
LOG_LEVEL = "info"
LOG_FILE = "./publishing/log/publishing-automation.log"
MAX_BYTES = 102400
BACKUP_COUNT = 5