"""
 This is final step. once bookmarking is done word doc is converted to non editable bookmarked pdf
"""
from win32com.client.dynamic import Dispatch
import pythoncom
import os


def doc_2_pdf_bookmarker(doc_file, doc_name, final_output_folder):
    pythoncom.CoInitialize()
    word = Dispatch("word.Application")  # initiation of word application
    word.Visible = False
    input_file = doc_file
    try:
        wb = word.Documents.Open(input_file, ConfirmConversions=False)
        # Please Mentiion the oupout destination path here
        # /** the destination path should be different fdrom input path**

        output_file = final_output_folder + doc_name[0:-5] + ".pdf"
        wb.ExportAsFixedFormat2(
            output_file,
            ExportFormat=17,
            OpenAfterExport=False,
            OptimizeFor=0,
            Range=0,
            Item=7,
            IncludeDocProps=True,
            KeepIRM=True,
            CreateBookmarks=1,
            DocStructureTags=True,
            BitmapMissingFonts=True,
            UseISO19005_1=True,
            OptimizeForImageQuality=True,
        )
        print("word doc is converted back to pdf formate with bookmarks added .\n")
        wb.Close()
        word.Quit()
    except:
        print("unabe")
        word.Quit()
