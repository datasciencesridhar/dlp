""" This is the final step. Once bookmarking and TOC generation is done the file will be 
converted to non-editable pdf and dsiplayed as Output file.
"""
from win32com.client.dynamic import Dispatch
import pythoncom
import os


def pdf_2_pdf_bookmarker(pdf_name, final_name, final_output_folder):
    pythoncom.CoInitialize()
    word = Dispatch("word.Application")  # initiation of word application
    word.Visible = False
    input_file = os.path.abspath(pdf_name)
    try:
        wb = word.Documents.Open(input_file, ConfirmConversions=False)
        # Please Mentiion the oupout destination path here
        # /** the destination path should be different fdrom input path**
        output_file = final_output_folder + final_name
        print("\n", output_file, "\n")
        wb.ExportAsFixedFormat2(
            output_file,
            ExportFormat=17,
            OpenAfterExport=False,
            OptimizeFor=0,
            Range=0,
            Item=7,
            IncludeDocProps=True,
            KeepIRM=True,
            CreateBookmarks=1,
            DocStructureTags=True,
            BitmapMissingFonts=True,
            UseISO19005_1=True,
            OptimizeForImageQuality=True,
        )
        print("adding bookmarks to the pdf is done.\n")
        wb.Close()
        word.Quit()
    except:
        word.Quit()
