# Publishing_automation
Automating the document level publishing and submission level publishing jobs. Involves Pdf bookmarking, OCR, TOC generation etc.
