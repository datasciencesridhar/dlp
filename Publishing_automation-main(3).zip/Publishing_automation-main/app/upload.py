# Input upload function rendered using flask
from flask import render_template, request, redirect, jsonify, make_response


def upload():
    if request.method == "POST":
        filesize = request.cookies.get("filesize")
        file = request.files["files"]
        print(f"Filsize: (filesize)")
        print(file)

        res = make_response(jsonify({"message": f"{file.filename} uploaded"}), 200)

        return res

    return render_template("upload.html")
