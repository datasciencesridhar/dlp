"""
Unit tests for logging formatter
"""
import logging
import json

# from our_logging.logging_formatter import LoggingFormatter
from publishing.aim_logging.logging_formatter import LoggingFormatter


def test_log_with_spec(caplog):
    """
    Test that the spec is correct
    """
    fmt = LoggingFormatter()
    with caplog.at_level(logging.INFO):
        logging.info("This is a test log")
        log = json.loads(fmt.format(caplog.records[0]))

        assert "timestamp" in log
        assert "thread" in log
        assert "level" in log
        assert "message" in log
        assert "logger" in log


def test_log_with_exception(caplog):
    """
    Test that exceptions are handled properly
    """
    fmt = LoggingFormatter()
    with caplog.at_level(logging.INFO):
        logging.info("This is an exception log", exc_info=ValueError("Error"))
        log = json.loads(fmt.format(caplog.records[0]))

        assert "timestamp" in log
        assert "thread" in log
        assert "level" in log
        assert "message" in log
        assert "logger" in log
