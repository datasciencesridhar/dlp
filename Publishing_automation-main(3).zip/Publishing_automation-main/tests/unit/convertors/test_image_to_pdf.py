"""
Test unit test module tests the image to pdf conversion.
"""
import pytest
import logging
from publishing.convertors.image_to_pdf import _convert_jpg_to_pdf


@pytest.mark.parametrize(
    "image_file",
    [
        ("./tests/data/jpg_image_pdf.jpeg"),
        ("./tests/data/jpg_image_pdf.jpg"),
    ],
)
def test_jpg_image_to_pdf_success(caplog, image_file):
    # Assert that the jpg image is converted successfully
    with caplog.at_level(logging.INFO):
        _ = _convert_jpg_to_pdf(image_file)
        assert "successfully done" in caplog.text
