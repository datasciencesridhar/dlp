import pytest
import logging
from publishing.convertors.ocr_to_pdf import _pdf_scaler


@pytest.mark.parametrize(
    "pdf_file",
    [
        ("./tests/data/sample1.pdf"),
    ],
)
def test_pdf_scaler_success(caplog, pdf_file):
    # Assert that the ocr image is converted to pdf successfully
    with caplog.at_level(logging.INFO):
        scaled_pdf = _pdf_scaler(pdf_file, 1)
        assert "successfully done" in caplog.text
